const pool = require('../db/connection');

const registerQuery = (req,res) =>{
    const {email, password} = req.body;

    pool.query('SELECT * FROM users WHERE email = $1', [email], (error, results) => {
        if (error) {
            res.status(500).json({ error: 'Database error' });
        } else if (results.rows.length > 0) {
            res.status(400).json({ error: 'Username already exists' });
        } else {
            resgisterUser(email, password, res);
        }
    });
}

const resgisterUser = (email, password, res) => {

    pool.query('INSERT INTO users (email, password) VALUES ($1, $2) RETURNING *', [email, password], (error, results) => {
        if (error) {
            res.status(500).json({ error: 'Database error' });
        } else {
            res.status(201).json(results.rows[0]);
        }
    });
}

module.exports = registerQuery;