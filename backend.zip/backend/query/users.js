const pool = require('../db/connection');

const getUsersQuery = (req, res) => {
    pool.query('SELECT (name,email,age,gender,is_active,created_at) FROM users', (error, results) => {
        if (error) {
            res.status(500).json({ error: 'Database error' });
        } else {
            res.status(200).json(results.rows);
        }
    });
}

const showUserQuery = (req, res) => {
    const { id } = req.params;

    pool.query('SELECT * FROM users WHERE id = $1', [id], (error, results) => {
        if (error) {
            res.status(500).json({ error: 'Database error' });
        } else if (results.rows.length === 0) {
            res.status(404).json({ error: 'User not found' });
        } else {
            res.status(200).json(results.rows[0]);
        }
    });
}

module.exports = {
    getUsersQuery,
    showUserQuery
};