const pool = require('../db/connection');

const loginQuery = (req, res) => {
    const { email, password } = req.body;

    pool.query('SELECT * FROM users WHERE email = $1 AND password = $2', [email, password], (error, results) => {
        if (error) {
            res.status(500).json({ message: 'Database error' });
        } else if (results.rows.length === 0) {
            res.status(401).json({ message: 'Invalid email or password' });
        } else {
            res.status(200).json({ message: 'Login successful', user: results.rows[0] });
        }
    });
}

module.exports = loginQuery;