const express = require('express')
const app = express()
const port = 3000
const registerQuery = require('./query/register_query');
const loginQuery = require('./query/login_query');
const { getUsersQuery, showUserQuery } = require('./query/users');
const cors = require('cors');

app.use(cors());
app.use(express.json());



app.get('/', (req, res) => res.send('Hello World!'))



app.post('/register',registerQuery);

app.post('/login',loginQuery);

app.get('/users', getUsersQuery);

app.get('/users/:id', showUserQuery);


app.listen(port, () => console.log(`Example app listening on port ${port}!`))