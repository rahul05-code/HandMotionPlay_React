import { Edit, Trash2 } from "lucide-react";

const GAME_DATA = [
  {
    id: 1,
    title: "Canvas Drawing",
    difficulty: "Easy",
    description: "Free hand drawing exercise",
    stats: { today: 124, total: "8,520", avg: 780 },
    engagement: 85,
    difficultyColor: "#10b981", // green
    difficultyBg: "rgba(16, 185, 129, 0.2)"
  },
  {
    id: 2,
    title: "Shape Tracing",
    difficulty: "Medium",
    description: "Accuracy based shape tracing",
    stats: { today: 92, total: "6,450", avg: 620 },
    engagement: 65,
    difficultyColor: "#eab308", // yellow
    difficultyBg: "rgba(234, 179, 8, 0.2)"
  },
  {
    id: 3,
    title: "Target Shooting",
    difficulty: "Hard",
    description: "Speed and precision training",
    stats: { today: 64, total: "4,230", avg: 450 },
    engagement: 45,
    difficultyColor: "#ef4444", // red
    difficultyBg: "rgba(239, 68, 68, 0.2)"
  }
];

const ManageGames = () => {
  return (
    <div className="page-container" style={{ paddingTop: '2rem' }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ marginBottom: '0.5rem', fontSize: '2.5rem' }}>Manage Games</h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>Manage your learning modules and games.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1.5rem', marginBottom: '2rem' }}>
        {GAME_DATA.map(game => (
          <div key={game.id} style={{
            backgroundColor: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            borderRadius: '12px',
            padding: '1.5rem',
            display: 'flex',
            flexDirection: 'column'
          }}>
            {/* Header: Title and Difficulty */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
              <h3 style={{ fontSize: '1.25rem', margin: 0 }}>{game.title}</h3>
              <span style={{ 
                backgroundColor: game.difficultyBg, 
                color: game.difficultyColor,
                padding: '0.2rem 0.6rem',
                borderRadius: '12px',
                fontSize: '0.75rem',
                fontWeight: 'bold'
              }}>
                {game.difficulty}
              </span>
            </div>
            
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '1.5rem', flex: 1 }}>{game.description}</p>
            
            {/* Stats Row */}
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
              <div>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem', marginBottom: '0.2rem' }}>Played Today</div>
                <div style={{ color: 'var(--text-main)', fontSize: '1.1rem', fontWeight: 'bold' }}>{game.stats.today}</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem', marginBottom: '0.2rem' }}>Total Players</div>
                <div style={{ color: 'var(--text-main)', fontSize: '1.1rem', fontWeight: 'bold' }}>{game.stats.total}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem', marginBottom: '0.2rem' }}>Avg Score</div>
                <div style={{ color: 'var(--text-main)', fontSize: '1.1rem', fontWeight: 'bold' }}>{game.stats.avg}</div>
              </div>
            </div>

            {/* Engagement Progress Bar */}
            <div style={{ marginBottom: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
                <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem', fontWeight: '600' }}>Player Engagement</span>
                <span style={{ color: 'var(--success)', fontSize: '0.85rem', fontWeight: 'bold' }}>{game.engagement}%</span>
              </div>
              <div style={{ width: '100%', height: '8px', backgroundColor: 'var(--bg-secondary)', borderRadius: '4px', overflow: 'hidden' }}>
                <div style={{ width: `${game.engagement}%`, height: '100%', backgroundColor: 'var(--success)', borderRadius: '4px' }}></div>
              </div>
            </div>

            {/* Action Buttons */}
            <div style={{ display: 'flex', gap: '1rem' }}>
              <button style={{ 
                flex: 1, 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'center', 
                gap: '0.5rem',
                padding: '0.6rem',
                backgroundColor: '#059669', // solid green
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontWeight: 'bold',
                cursor: 'pointer'
              }}>
                <Edit size={16} /> Edit
              </button>
              <button style={{ 
                flex: 1, 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'center', 
                gap: '0.5rem',
                padding: '0.6rem',
                backgroundColor: '#dc2626', // solid red
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontWeight: 'bold',
                cursor: 'pointer'
              }}>
                <Trash2 size={16} /> Delete
              </button>
            </div>

          </div>
        ))}
      </div>

      {/* Summary Footer Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1.5rem' }}>
        <div style={{ 
          backgroundColor: 'var(--card-bg)', 
          border: '1px solid var(--border-color)', 
          borderRadius: '8px', 
          padding: '1.5rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.5rem'
        }}>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.9rem', fontWeight: '600' }}>Total Games</div>
          <div style={{ color: 'white', fontSize: '1.25rem', fontWeight: 'bold' }}>3</div>
        </div>
        <div style={{ 
          backgroundColor: 'var(--card-bg)', 
          border: '1px solid var(--border-color)', 
          borderRadius: '8px', 
          padding: '1.5rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.5rem'
        }}>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.9rem', fontWeight: '600' }}>Total Players</div>
          <div style={{ color: 'white', fontSize: '1.25rem', fontWeight: 'bold' }}>1,250</div>
        </div>
        <div style={{ 
          backgroundColor: 'var(--card-bg)', 
          border: '1px solid var(--border-color)', 
          borderRadius: '8px', 
          padding: '1.5rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.5rem'
        }}>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.9rem', fontWeight: '600' }}>Avg Score</div>
          <div style={{ color: 'white', fontSize: '1.25rem', fontWeight: 'bold' }}>850</div>
        </div>
      </div>
      
    </div>
  );
};

export default ManageGames;
