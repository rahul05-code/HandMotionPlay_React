import { Search, Edit, Trash2 } from "lucide-react";
import Card from "../../components/common/Card";

const DUMMY_USERS = [
  ...Array(5).fill({}).map((_, i) => ({
    id: i + 1,
    name: "John Doe",
    email: "john@example.com",
    joinDate: "2024-01-15",
    status: i === 2 ? "inactive" : "active",
    gamesPlayed: 42,
    totalScore: "8,500"
  }))
];

const ManageUsers = () => {

  const userList = async(e) => {
    try {
      const req = await axios.get('http://localhost:3000/users');
      const res = req.data;
      
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <div className="page-container" style={{ paddingTop: '2rem' }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ marginBottom: '0.5rem', fontSize: '2.5rem' }}>Manage User</h1>
        <p style={{ color: 'var(--text-muted)', fontSize: '1.1rem' }}>View and manage all platform users.</p>
      </div>

      {/* Search Bar */}
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        backgroundColor: 'var(--card-bg)', 
        padding: '0.75rem 1.5rem',
        borderRadius: '8px',
        marginBottom: '1.5rem',
        border: '1px solid var(--border-color)'
      }}>
        <Search size={20} color="var(--text-main)" style={{ marginRight: '1rem' }} />
        <input 
          type="text" 
          placeholder="Search Users by name or email" 
          style={{ 
            background: 'transparent', 
            border: 'none', 
            outline: 'none', 
            color: 'var(--text-main)', 
            width: '100%',
            fontSize: '1rem'
          }} 
        />
      </div>

      {/* Data Table Container */}
      <div style={{ 
        border: '1px solid var(--border-color)', 
        borderRadius: '8px', 
        overflow: 'hidden',
        marginBottom: '2rem'
      }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ backgroundColor: 'var(--bg-secondary)', color: 'var(--text-main)', fontSize: '0.95rem' }}>
              <th style={{ padding: '1rem 1.5rem', fontWeight: 'bold' }}>Name</th>
              <th style={{ padding: '1rem 1.5rem', fontWeight: 'bold' }}>Email</th>
              <th style={{ padding: '1rem 1.5rem', fontWeight: 'bold' }}>Join Date</th>
              <th style={{ padding: '1rem 1.5rem', fontWeight: 'bold' }}>Status</th>
              <th style={{ padding: '1rem 1.5rem', fontWeight: 'bold' }}>Game played</th>
              <th style={{ padding: '1rem 1.5rem', fontWeight: 'bold' }}>Total Score</th>
              <th style={{ padding: '1rem 1.5rem', fontWeight: 'bold' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {DUMMY_USERS.map((user, idx) => (
              <tr 
                key={user.id} 
                style={{ 
                  backgroundColor: idx % 2 === 0 ? 'var(--bg-primary)' : 'var(--bg-secondary)',
                  borderBottom: idx === DUMMY_USERS.length - 1 ? 'none' : '1px solid var(--border-color)',
                  color: 'var(--text-main)',
                  fontSize: '0.95rem',
                  fontWeight: '600'
                }}
              >
                <td style={{ padding: '1rem 1.5rem' }}>{user.name}</td>
                <td style={{ padding: '1rem 1.5rem' }}>{user.email}</td>
                <td style={{ padding: '1rem 1.5rem' }}>{user.joinDate}</td>
                <td style={{ padding: '1rem 1.5rem' }}>
                  <span style={{
                    padding: '0.2rem 0.8rem',
                    borderRadius: '12px',
                    fontSize: '0.8rem',
                    fontWeight: 'bold',
                    backgroundColor: user.status === 'active' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)',
                    color: user.status === 'active' ? '#10b981' : '#ef4444'
                  }}>
                    {user.status}
                  </span>
                </td>
                <td style={{ padding: '1rem 1.5rem', fontWeight: 'bold', fontSize: '1.05rem' }}>{user.gamesPlayed}</td>
                <td style={{ padding: '1rem 1.5rem', fontSize: '0.8rem' }}>{user.totalScore}</td>
                <td style={{ padding: '1rem 1.5rem' }}>
                  <div style={{ display: 'flex', gap: '0.75rem' }}>
                    <button style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-main)' }}>
                      <Edit size={18} />
                    </button>
                    <button style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: '#ef4444' }}>
                      <Trash2 size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Footer Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1.5rem' }}>
        <div style={{ 
          backgroundColor: 'var(--card-bg)', 
          border: '1px solid var(--border-color)', 
          borderRadius: '8px', 
          padding: '1.5rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.5rem'
        }}>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.9rem', fontWeight: '600' }}>Total Users</div>
          <div style={{ color: 'var(--text-main)', fontSize: '1.25rem', fontWeight: 'bold' }}>5</div>
        </div>
        <div style={{ 
          backgroundColor: 'var(--card-bg)', 
          border: '1px solid var(--border-color)', 
          borderRadius: '8px', 
          padding: '1.5rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.5rem'
        }}>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.9rem', fontWeight: '600' }}>Active User</div>
          <div style={{ color: 'var(--text-main)', fontSize: '1.25rem', fontWeight: 'bold' }}>4</div>
        </div>
        <div style={{ 
          backgroundColor: 'var(--card-bg)', 
          border: '1px solid var(--border-color)', 
          borderRadius: '8px', 
          padding: '1.5rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.5rem'
        }}>
          <div style={{ color: 'var(--text-muted)', fontSize: '0.9rem', fontWeight: '600' }}>Avg Games Played</div>
          <div style={{ color: 'var(--text-main)', fontSize: '1.25rem', fontWeight: 'bold' }}>27.8</div>
        </div>
      </div>
      
    </div>
  );
};

export default ManageUsers;
